document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('task-input');
    const taskList = document.getElementById('task-list');
  
    taskForm.addEventListener('submit', (e) => {
      e.preventDefault();
      addTask(taskInput.value);
      taskInput.value = '';
    });
  
    function addTask(task) {
      if (task === '') return;
  
      const taskItem = document.createElement('li');
      const taskText = document.createElement('span');
      taskText.textContent = task;
  
      const completeButton = document.createElement('button');
      completeButton.textContent = 'Complete';
      completeButton.addEventListener('click', () => {
        completeTask(taskItem);
      });
  
      const deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.addEventListener('click', () => {
        deleteTask(taskItem);
      });
  
      taskItem.appendChild(taskText);
      taskItem.appendChild(completeButton);
      taskItem.appendChild(deleteButton);
      taskList.appendChild(taskItem);
    }
  
    function completeTask(taskItem) {
      taskList.removeChild(taskItem);
    }
  
    function deleteTask(taskItem) {
      taskList.removeChild(taskItem);
    }
  });
  