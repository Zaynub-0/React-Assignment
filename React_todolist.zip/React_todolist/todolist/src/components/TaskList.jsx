import React from 'react';
import Task from './Task';

const TaskList = ({ tasks, deleteTask, toggleTask }) => {
  return (
    <div>
      {tasks.map((task, index) => (
        <Task 
          key={index} 
          index={index} 
          task={task} 
          deleteTask={deleteTask} 
          toggleTask={toggleTask} 
        />
      ))}
    </div>
  );
};

export default TaskList;
