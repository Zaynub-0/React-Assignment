import React from 'react';

const Task = ({ task, index, deleteTask, toggleTask }) => {
  return (
    <div style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
      {task.name}
      <button onClick={() => toggleTask(index)}>Complete</button>
      <button onClick={() => deleteTask(index)}>Delete</button>
    </div>
  );
};

export default Task;
